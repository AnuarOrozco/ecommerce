package mx.uvm.anuar.ecommerce_platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommercePlatformAnuarApplicationTests {

	@Test
	void contextLoads() {
	}

}
